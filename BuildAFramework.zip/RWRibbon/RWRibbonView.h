//
//  RWRibbonView.h
//  RWUIControls
//
//  Created by Sam Davies on 29/01/2014.
//  Copyright (c) 2014 RayWenderlich. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RWRibbonView : UIView

@end
